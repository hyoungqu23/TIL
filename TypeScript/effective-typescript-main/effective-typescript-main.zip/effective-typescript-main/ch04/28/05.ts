interface State {
  pageText: string
  isLoading: boolean
  error?: string
}
declare let currentPage: string
function getUrlForPage(p: string) {
  return ''
}
async function changePage(state: State, newPage: string) {
  state.isLoading = true
  try {
    const response = await fetch(getUrlForPage(newPage))
    if (!response.ok) {
      throw new Error(`Unable to load ${newPage}: ${response.statusText}`)
    }
    const text = await response.text()
    state.isLoading = false
    state.pageText = text
  } catch (e) {
    state.error = '' + e
  }
}

export default {}
