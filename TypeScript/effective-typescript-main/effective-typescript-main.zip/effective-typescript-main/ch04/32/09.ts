interface Person {
  name: string
  birth?: {
    place: string
    date: Date
  }
}
const alanT: Person = {
  name: 'Alan Turing',
  birth: {
    // ~~~~ Property 'date' is missing in type
    //      '{ place: string; }' but required in type
    //      '{ place: string; date: Date; }'
    place: 'London',
  },
}

export default {}
