function sort(nums: readonly number[]) {
  /* ... */
}

export default {}
