/** Does not modify nums */
function sort(nums: number[]) {
  /* ... */
}

export default {}
