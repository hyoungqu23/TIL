const paragraphs: (readonly string[])[] = []

export default {}
