function parseCSV(input: string): { [columnName: string]: string }[] {
  const lines = input.split('\n')
  const [header, ...rows] = lines
  return rows.map(rowStr => {
    const row: { [columnName: string]: string } = {}
    rowStr.split(',').forEach((cell, i) => {
      row[header[i]] = cell
    })
    return row
  })
}
interface ProductRow {
  productId: string
  name: string
  price: string
}

declare let csvData: string
const products = parseCSV(csvData) as unknown as ProductRow[]
function safeParseCSV(input: string): { [columnName: string]: string | undefined }[] {
  return parseCSV(input)
}
type Vec3D = { [k in 'x' | 'y' | 'z']: number }
// Same as above
type ABC = { [k in 'a' | 'b' | 'c']: k extends 'b' ? string : number }
// Type ABC = {
//   a: number;
//   b: string;
//   c: number;
// }

export default {}
