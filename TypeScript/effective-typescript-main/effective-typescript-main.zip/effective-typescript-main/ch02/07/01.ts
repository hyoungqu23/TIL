const x: never = 12
// ~ Type '12' is not assignable to type 'never'

export default {}
