interface Identified {
  id: string
}

export default {}
