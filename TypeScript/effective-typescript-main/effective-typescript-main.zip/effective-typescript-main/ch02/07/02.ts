type A = 'A'
type B = 'B'
type Twelve = 12

export default {}
