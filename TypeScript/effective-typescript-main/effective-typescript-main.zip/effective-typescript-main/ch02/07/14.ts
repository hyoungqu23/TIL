function getKey<K extends string>(val: any, key: K) {
  // ...
}

export default {}
