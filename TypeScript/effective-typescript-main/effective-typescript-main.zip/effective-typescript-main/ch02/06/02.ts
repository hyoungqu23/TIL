const response = fetch('http://example.com')

export default {}
