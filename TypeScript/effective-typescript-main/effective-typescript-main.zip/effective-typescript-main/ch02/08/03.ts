type T1 = 'string literal'
type T2 = 123
const v1 = 'string literal'
const v2 = 123

export default {}
