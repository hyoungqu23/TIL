type Pair = [number, number]
type StringList = string[]
type NamedNums = [string, ...number[]]

export default {}
