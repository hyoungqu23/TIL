interface Tuple {
  0: number
  1: number
  length: 2
}
const t: Tuple = [10, 20] // OK

export default {}
