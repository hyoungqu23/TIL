type AorB = 'a' | 'b'

export default {}
