type TState = {
  name: string
  capital: string
}

export default {}
