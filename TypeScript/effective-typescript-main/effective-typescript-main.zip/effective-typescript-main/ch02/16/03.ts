const xs = [1, 2, 3]
for (const x of xs) {
  x // Type is number
}

export default {}
