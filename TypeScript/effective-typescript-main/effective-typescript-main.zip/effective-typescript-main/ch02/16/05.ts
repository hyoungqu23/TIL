const xs = [1, 2, 3]
for (let i = 0; i < xs.length; i++) {
  const x = xs[i]
  if (x < 0) break
}

export default {}
