const s: String = 'primitive'
const n: Number = 12
const b: Boolean = true

export default {}
