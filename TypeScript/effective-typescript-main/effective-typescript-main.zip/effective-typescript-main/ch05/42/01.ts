function parseYAML(yaml: string): any {
  // ...
}

export default {}
