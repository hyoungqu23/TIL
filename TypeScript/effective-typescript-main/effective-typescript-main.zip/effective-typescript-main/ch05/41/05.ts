function somethingDangerous() {}

export default {}
