declare function cacheLast<T extends Function>(fn: T): T

export default {}
