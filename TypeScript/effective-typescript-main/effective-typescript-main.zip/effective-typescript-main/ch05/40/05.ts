declare function shallowEqual(a: any, b: any): boolean
declare function shallowObjectEqual<T extends object>(a: T, b: T): boolean

export default {}
