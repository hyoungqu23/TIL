const utils = {
  buildColumnInfo(s: any, name: string): any {},
}
declare let appState: { dataSchema: unknown }
declare module 'my-module'

export default {}
