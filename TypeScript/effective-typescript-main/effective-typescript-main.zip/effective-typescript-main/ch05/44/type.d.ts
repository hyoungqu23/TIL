declare module 'my-module'
