function turnLightOn() {}
function turnLightOff() {}

export default {}
