function asNumber(val: number | string): number {
  return val as number
}

export default {}
