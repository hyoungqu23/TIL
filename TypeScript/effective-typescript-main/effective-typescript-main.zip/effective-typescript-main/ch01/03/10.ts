function add(a: number, b: number) {
  return a + b
}
// ~~~ Duplicate function implementation
function add(a: string, b: string) {
  return a + b
}
// ~~~ Duplicate function implementation

export default {}
