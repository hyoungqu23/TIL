let x = 'hello'
x = 1234

export default {}
