// tsConfig: {"noImplicitAny":true,"strictNullChecks":false}

const x: number = null // OK, null is a valid number

export default {}
