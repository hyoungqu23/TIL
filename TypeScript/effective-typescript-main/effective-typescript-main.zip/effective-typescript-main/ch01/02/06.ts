// tsConfig: {"noImplicitAny":true,"strictNullChecks":true}

const x: number = null
//    ~ Type 'null' is not assignable to type 'number'

export default {}
