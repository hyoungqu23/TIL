interface PostgresDB {
  runQuery: (sql: string) => any[]
}

export default {}
