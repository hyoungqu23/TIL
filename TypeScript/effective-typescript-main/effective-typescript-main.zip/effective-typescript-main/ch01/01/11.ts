const names = ['Alice', 'Bob']
console.log(names[2].toUpperCase())

export default {}
