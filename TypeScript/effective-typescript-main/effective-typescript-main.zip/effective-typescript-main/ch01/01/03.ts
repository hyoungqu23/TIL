let city = 'new york city'
console.log(city.toUppercase())
// ~~~~~~~~~~~ Property 'toUppercase' does not exist on type
//             'string'. Did you mean 'toUpperCase'?

export default {}
