function greet(who: string) {
  console.log('Hello', who)
}

greet('jn')

export default {}
