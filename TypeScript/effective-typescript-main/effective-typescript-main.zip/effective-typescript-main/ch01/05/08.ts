interface ComponentProps {
  onSelectItem: (id: number) => void
}

export default {}
