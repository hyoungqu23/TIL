interface ComponentProps {
  onSelectItem: (item: any) => void
}

export default {}
