const square = (x: number) => x * x
test('square a number', () => {
  square(1)
  square(2)
})

export default {}
