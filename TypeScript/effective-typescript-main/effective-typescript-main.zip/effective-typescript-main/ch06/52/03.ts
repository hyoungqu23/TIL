const square = (x: number) => x * x

export default {}
