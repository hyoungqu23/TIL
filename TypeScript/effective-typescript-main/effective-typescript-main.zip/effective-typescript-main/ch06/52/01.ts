declare function map<U, V>(array: U[], fn: (u: U) => V): V[]

export default {}
