function double(x: number | string): number | string
function double(x: any) {
  return x + x
}

export default {}
