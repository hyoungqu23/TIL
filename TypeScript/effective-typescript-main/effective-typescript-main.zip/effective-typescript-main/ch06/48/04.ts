interface Vector3D {}

export default {}
