declare let hasMiddle: boolean
const firstLast = { first: 'Harry', last: 'Truman' }

export default {}
