interface Point {
  x: number
  y: number
}
const pt: Point = {
  x: 3,
  y: 4,
}

export default {}
