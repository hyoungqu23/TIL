interface Point {
  x: number
  y: number
}
const pt = {} as Point
pt.x = 3
pt.y = 4 // OK

export default {}
