interface Point {
  x: number
  y: number
}

export default {}
