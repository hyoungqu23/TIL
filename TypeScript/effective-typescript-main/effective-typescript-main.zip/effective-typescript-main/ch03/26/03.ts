type Language = 'JavaScript' | 'TypeScript' | 'Python'
function setLanguage(language: Language) {
  /* ... */
}
let language: Language = 'JavaScript'
setLanguage(language) // OK

export default {}
