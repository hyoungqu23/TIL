type Language = 'JavaScript' | 'TypeScript' | 'Python'
function setLanguage(language: Language) {
  /* ... */
}
const language = 'JavaScript'
setLanguage(language) // OK

export default {}
