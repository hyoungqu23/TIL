const axis1: string = 'x' // Type is string
const axis2 = 'y' // Type is "y"

export default {}
