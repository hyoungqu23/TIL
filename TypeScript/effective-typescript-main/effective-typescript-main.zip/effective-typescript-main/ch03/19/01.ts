let x: number = 12

export default {}
