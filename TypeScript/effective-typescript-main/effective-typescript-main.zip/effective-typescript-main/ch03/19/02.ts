let x = 12

export default {}
