function parseNumber(str: string, base = 10) {
  // ...
}

export default {}
